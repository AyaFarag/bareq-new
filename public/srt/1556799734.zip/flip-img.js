$('#card1').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card2').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card3').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card4').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card5').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card6').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card7').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card8').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card9').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card10').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card11').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});

$('#card12').flip({
    axis: 'y',
    trigger: 'click',
    speed: 500,
});
